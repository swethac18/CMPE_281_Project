<?php
        return [
                's3' => [
                'key' => 'AKIAI3YSCN42W5DKMGHA',
                'secret' => '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',
                'bucket' => 'my-assignment-2',
		'replication' => 'replica-bucket'
		]
        ];
?>	
