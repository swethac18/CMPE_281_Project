<?php
	require 'start.php';
		
	use Aws\CloudFront\CloudFrontClient;

	$objects = $s3->getIterator('ListObjects', 
	[
		'Bucket' => $config['s3']['bucket']
	]);

	$replication = $s3->getIterator('ListObjects', 
	[
		'Bucket' => $config['s3']['replication']
	]);
	
	$cloudFrontDomain= "https://d3pb1fjh9d7prf.cloudfront.net/";
	try {
	$cloudfront = CloudFrontClient::factory([
		'private_key' => 'pk-APKAJSLS4KKD5BVURCGQ.pem',
		'key_pair_id' => 'APKAJSLS4KKD5BVURCGQ'
	]);
	} catch(Exception $e) {
		echo "Cloudfront issue";
	}

?>

<html>
	<head>
		<title> Listing all S3 files </title>
	</head>
<body>
	<h1> List of S3 files uploaded by various users </h1>
	<h2> Main AZ US West(oregon) </h2>
	<table border = 1>
	<tr>
	<td><b> File </b> </td>
	<td> <b> Last updated time </b> </td>
	<td> <b> Created by </b></td>
	<td> <b> Download from Cloudfront:<br>  <?php echo $cloudFrontDomain?> </b></td>
 	<td> <b> Download from S3 Transfer Accelerated Link </b> </td>
	<td> <b> Directly from S3 origin (slowest), <br> link expires in 10 mins for security reasons </b> </td>	
	</tr>
	<?php foreach($objects as $object): 
	?>
	
	<tr>
		<td> <?php echo $object['Key']; ?>  </td>
		<td> <?php echo $object['LastModified']; ?> </td>
		<td> <?php echo $object['Owner']['DisplayName']; ?> </td>
		<td> <a href="<?php 
					echo $cloudFrontDomain.$object['Key'];
			      ?>"> Cloud front URL </td>
		<td> <a href="<?php  
					$originalURL = $s3->getObjectUrl($config['s3']['bucket'],$object['Key']);
					$source= "my-assignment-2.s3.amazonaws.com";
					$destination = "my-assignment-2.s3-accelerate.amazonaws.com";
					$acceleratedURL = str_replace($source, $destination, $originalURL);
					echo $acceleratedURL;

		?>"> S3 Transfer Accelerated Link</td>
		
		<td> <a href="<?php echo $s3->getObjectUrl($config['s3']['bucket'],$object['Key'],'+10 minute')?>" download = "<?php $object['Key']?>"> Pre-signed S3 origin URL</a></td>

	</tr>
	<tr></tr>

	<?php endforeach; ?>
	</table>

	
	<h2> Replication in AZ US WEST (N California) </h2>
	<table border = 1>
	<tr>
	<td><b> File </b> </td>
	<td> <b> Last updated time </b> </td>
	<td> <b> Created by </b></td>
	<td> <b> Download from Cloudfront:<br>   <?php echo $cloudFrontDomain?> </b></td>
 	<td> <b> S3 Transfer Accelerated Link </b> </td>
	<td> <b> Directly from S3 origin (slowest), <br> link expires in 10 mins for security reasons </b> </td>	

	</tr>
	<?php foreach($replication as $object): 
	?>
	
	<tr>
		<td> <?php echo $object['Key']; ?>  </td>
		<td> <?php echo $object['LastModified']; ?> </td>
		<td> <?php echo $object['Owner']['DisplayName']; ?> </td>
		<td> <a href="<?php 
					echo $cloudFrontDomain.$object['Key'];
			      ?>"> Cloud front URL </td>

		<td> <a href="<?php  
					$originalURL = $s3->getObjectUrl($config['s3']['bucket'],$object['Key']);
					$source= "my-assignment-2.s3.amazonaws.com";
					$destination = "my-assignment-2.s3-accelerate.amazonaws.com";
					$acceleratedURL = str_replace($source, $destination, $originalURL);
					echo $acceleratedURL;

		?>"> Click here</td>

		<td> <a href="<?php echo $s3->getObjectUrl($config['s3']['bucket'],$object['Key'],'+10 minute')?>" download = "<?php $object['Key']?>"> Pre-signed S3 origin URL</a></td>
	</tr>
	<tr></tr>

	<?php endforeach; ?>
	</table>

	<?php
		$objects = $s3->getIterator('ListObjects', 
	[
		'Bucket' => $config['s3']['bucket']
	]);

	$replication = $s3->getIterator('ListObjects', 
	[
		'Bucket' => $config['s3']['replication']
	]);
		if (iterator_count($replication) == iterator_count($objects)) {
			echo "<h3> Everything looks good across oregon and northern CA </h3>";
			echo "Total number of objects on S3: ";
			echo iterator_count($replication);
		} else {
		   if (iterator_count($replication) > iterator_count($objects)) {
			echo "<h3> S3 Objects <font color=red> missing in main data centre </font> </h3>";
			echo "<h3> please look into replication for the missing object </h3>";
			echo "Total number of objects on replication:";
			echo iterator_count($replication);

		   } else { 
			echo "<h3> S3 Objects missing in replication data centre and not in sync with main AZ region </h3>";
			echo "<h3> Wait for replication to complete. </h3>";
			echo "Total number of objects on replication:";
			echo iterator_count($replication);

		   }
		}
	?>

</body>
</html>
